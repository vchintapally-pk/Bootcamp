# Bigdata Bootcamp

####      Week - 1  

<br />
<br />

![logo](https://user-images.githubusercontent.com/73540298/99816743-aeaddb80-2b11-11eb-99f1-20a5fcf77060.png) &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;![pycharm_logo_300x300](https://user-images.githubusercontent.com/73540298/99819532-33e6bf80-2b15-11eb-9bd3-fbe3ab7ebd98.png)

<br />
<br />

#### Week - 2
<br />
<br />


![Classic_flat_look_3D svg](https://user-images.githubusercontent.com/73540298/99817162-31cf3180-2b12-11eb-8318-e50e209d8346.png)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;![logo](https://user-images.githubusercontent.com/73540298/99816743-aeaddb80-2b11-11eb-99f1-20a5fcf77060.png)

<br />
<br />


#### Week - 3 & 4

<br />
<br />


![scala](https://user-images.githubusercontent.com/73540298/99817710-e6695300-2b12-11eb-815c-59d4523a450c.png)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;![intellij-idea-tutorial](https://user-images.githubusercontent.com/73540298/99819876-a788cc80-2b15-11eb-8b36-ab07fa1b0378.png)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;![25231](https://user-images.githubusercontent.com/73540298/99819931-bc656000-2b15-11eb-880f-b2b6161fb23c.png)
<br />
<br />



#### Week - 5
<br />
<br />

![mysql-logo-png-transparent](https://user-images.githubusercontent.com/73540298/99820035-dacb5b80-2b15-11eb-881c-121622553546.png)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;![brand](https://user-images.githubusercontent.com/73540298/99820144-fc2c4780-2b15-11eb-91ad-f3e2c20a2bc5.gif)
<br />
<br />




