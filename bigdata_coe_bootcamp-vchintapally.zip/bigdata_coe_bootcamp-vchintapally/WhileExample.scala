object WhileExample extends App {

      var a = 10;                       // Initialization
      while( a<=20 ){                // Condition
        println(a);
        a = a+2                        // Incrementation
      }


}
