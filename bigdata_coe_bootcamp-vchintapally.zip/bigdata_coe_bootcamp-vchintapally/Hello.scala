object Hello extends App{
print("Hello World")
}
